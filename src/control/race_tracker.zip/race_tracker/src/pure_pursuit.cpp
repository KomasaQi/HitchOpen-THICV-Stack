#include "race_tracker/pure_pursuit.h"
#include <tf/transform_broadcaster.h>
#include <tf/transform_listener.h>
#include <cmath>

namespace race_tracker
{

PurePursuit::PurePursuit()
  : wheel_base_(2.7),  // 默认轴距，会从参数服务器读取
    lookahead_distance_(5.0),  // 默认前视距离
    max_steering_angle_(0.5236),  // 约30度（弧度）
    min_steering_angle_(-0.5236)  // 约-30度（弧度）
{
}

bool PurePursuit::initialize(ros::NodeHandle& nh, ros::NodeHandle& private_nh)
{
  // 从参数服务器加载参数
  private_nh.param("wheel_base", wheel_base_, wheel_base_);
  private_nh.param("lookahead_distance", lookahead_distance_, lookahead_distance_);
  private_nh.param("max_steering_angle", max_steering_angle_, max_steering_angle_);
  private_nh.param("min_steering_angle", min_steering_angle_, min_steering_angle_);

  ROS_INFO_STREAM("PurePursuit initialized with parameters: "
                  << "wheel_base=" << wheel_base_ << ", "
                  << "lookahead_distance=" << lookahead_distance_ << ", "
                  << "max_steering_angle=" << max_steering_angle_);

  return true;
}

void PurePursuit::computeControl(const race_msgs::VehicleStatus& vehicle_status,
                                const race_msgs::Path& path,
                                race_msgs::Control& control_cmd)
{
  if (path.points.empty())
  {
    ROS_WARN_THROTTLE(1.0, "PurePursuit: Received empty path");
    return;
  }

  // 查找目标路径点
  int target_idx = findTargetPoint(vehicle_status.pose, path);
  if (target_idx == -1)
  {
    ROS_WARN_THROTTLE(1.0, "PurePursuit: Could not find target point");
    return;
  }

  // 计算转向角
  double steering_angle = calculateSteeringAngle(vehicle_status.pose, path.points[target_idx]);

  // 限制转向角在最大范围内
  steering_angle = std::max(min_steering_angle_, std::min(max_steering_angle_, steering_angle));

  // 设置控制指令
  control_cmd.lateral.steering_angle = steering_angle;
  
  // 简单设置转向角速度（可以根据需要更复杂的计算）
  control_cmd.lateral.steering_angle_velocity = 0.5;  // 示例值

  // 如果是双轴转向模式，可以在这里设置后轮转向角
  if (control_cmd.steering_mode == race_msgs::Control::DUAL_STEERING_MODE)
  {
    // 简单的双轴转向策略：后轮转向角与前轮相反，比例系数可调整
    control_cmd.lateral.rear_wheel_angle = -0.3 * steering_angle;
    control_cmd.lateral.rear_wheel_angle_velocity = -0.3 * control_cmd.lateral.steering_angle_velocity;
  }
  else
  {
    control_cmd.lateral.rear_wheel_angle = 0.0;
    control_cmd.lateral.rear_wheel_angle_velocity = 0.0;
  }
}

int PurePursuit::findTargetPoint(const geometry_msgs::Pose& vehicle_pose, const race_msgs::Path& path)
{
  // 获取车辆位置
  double vehicle_x = vehicle_pose.position.x;
  double vehicle_y = vehicle_pose.position.y;

  // 获取车辆朝向（偏航角）
  tf::Quaternion quat;
  tf::quaternionMsgToTF(vehicle_pose.orientation, quat);
  double yaw = tf::getYaw(quat);

  // 计算车辆前进方向单位向量
  double dx = cos(yaw);
  double dy = sin(yaw);

  // 寻找距离车辆前视距离最近的路径点
  double min_dist_diff = std::numeric_limits<double>::max();
  int target_idx = -1;

  for (size_t i = 0; i < path.points.size(); ++i)
  {
    // 计算路径点与车辆的距离
    double px = path.points[i].pose.position.x;
    double py = path.points[i].pose.position.y;
    
    double dist = hypot(px - vehicle_x, py - vehicle_y);
    
    // 计算距离与前视距离的差值
    double dist_diff = fabs(dist - lookahead_distance_);
    
    // 检查该点是否在车辆前进方向上
    double proj = (px - vehicle_x) * dx + (py - vehicle_y) * dy;
    
    if (proj > 0 && dist_diff < min_dist_diff)
    {
      min_dist_diff = dist_diff;
      target_idx = i;
    }
  }

  return target_idx;
}

double PurePursuit::calculateSteeringAngle(const geometry_msgs::Pose& vehicle_pose, 
                                          const race_msgs::PathPoint& target_point)
{
  // 车辆位置
  double x = vehicle_pose.position.x;
  double y = vehicle_pose.position.y;

  // 目标点位置
  double tx = target_point.pose.position.x;
  double ty = target_point.pose.position.y;

  // 车辆朝向（偏航角）
  tf::Quaternion quat;
  tf::quaternionMsgToTF(vehicle_pose.orientation, quat);
  double yaw = tf::getYaw(quat);

  // 将目标点转换到车辆坐标系
  double dx = tx - x;
  double dy = ty - y;
  
  // 旋转到车辆坐标系（车身向前为x轴）
  double x_rel = dx * cos(yaw) + dy * sin(yaw);
  double y_rel = -dx * sin(yaw) + dy * cos(yaw);

  // Pure Pursuit算法计算转向角
  // 公式: delta = arctan(2 * L * y_rel / (x_rel^2 + y_rel^2))
  double distance_sq = x_rel * x_rel + y_rel * y_rel;
  if (distance_sq < 0.01)  // 避免除以零
  {
    return 0.0;
  }

  double steering_angle = atan2(2 * wheel_base_ * y_rel, distance_sq);
  
  return steering_angle;
}

} // namespace race_tracker

// 注册插件
#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(race_tracker::PurePursuit, race_tracker::ControllerPlugin)
