#include "race_tracker/controller_manager.h"
#include <pluginlib/class_list_macros.h>

namespace race_tracker
{

ControllerManager::ControllerManager(ros::NodeHandle& nh, ros::NodeHandle& private_nh)
  : nh_(nh), private_nh_(private_nh)
{
  // 从参数服务器获取话题名称，默认使用指定话题
  private_nh_.param<std::string>("path_topic", path_topic_, "/race/local_path");
  private_nh_.param<std::string>("vehicle_status_topic", vehicle_status_topic_, "/race/vehicle_state");
  private_nh_.param<std::string>("control_topic", control_topic_, "/race/control");
  private_nh_.param<double>("control_rate", control_rate_, 50.0);

  // 订阅路径和车辆状态话题
  path_sub_ = nh_.subscribe(path_topic_, 1, &ControllerManager::pathCallback, this);
  vehicle_status_sub_ = nh_.subscribe(vehicle_status_topic_, 1, &ControllerManager::vehicleStatusCallback, this);
  
  // 发布控制指令话题
  control_pub_ = nh_.advertise<race_msgs::Control>(control_topic_, 1);

  // 初始化插件加载器
  try
  {
    controller_loader_.reset(new pluginlib::ClassLoader<ControllerPlugin>(
        "race_tracker", "race_tracker::ControllerPlugin"));
  }
  catch (pluginlib::PluginlibException& ex)
  {
    ROS_ERROR_STREAM("Failed to create controller loader: " << ex.what());
    return;
  }

  // 加载配置的控制器插件
  XmlRpc::XmlRpcValue controllers_params;
  if (private_nh_.getParam("controllers", controllers_params))
  {
    ROS_ASSERT(controllers_params.getType() == XmlRpc::XmlRpcValue::TypeArray);
    
    for (int i = 0; i < controllers_params.size(); ++i)
    {
      ROS_ASSERT(controllers_params[i].getType() == XmlRpc::XmlRpcValue::TypeString);
      std::string controller_name = static_cast<std::string>(controllers_params[i]);
      
      try
      {
        boost::shared_ptr<ControllerPlugin> controller = 
            controller_loader_->createInstance(controller_name);
        
        // 为每个控制器创建私有命名空间
        ros::NodeHandle controller_nh(private_nh_, "controllers/" + controller_name);
        if (controller->initialize(nh_, controller_nh))
        {
          controllers_.push_back(controller);
          ROS_INFO_STREAM("Successfully loaded controller: " << controller->getPluginName());
        }
        else
        {
          ROS_ERROR_STREAM("Failed to initialize controller: " << controller_name);
        }
      }
      catch (pluginlib::PluginlibException& ex)
      {
        ROS_ERROR_STREAM("Failed to load controller " << controller_name << ": " << ex.what());
      }
    }
  }
  else
  {
    ROS_WARN("No controllers specified in parameter 'controllers'");
  }

  // 启动控制定时器
  control_timer_ = nh_.createTimer(ros::Duration(1.0 / control_rate_),
                                  [this](const ros::TimerEvent&) { computeControl(); });
}

void ControllerManager::pathCallback(const race_msgs::Path::ConstPtr& msg)
{
  current_path_ = msg;
}

void ControllerManager::vehicleStatusCallback(const race_msgs::VehicleStatus::ConstPtr& msg)
{
  current_status_ = msg;
}

void ControllerManager::computeControl()
{
  // 检查是否有有效的路径和车辆状态
  if (!current_path_ || !current_status_)
  {
    ROS_DEBUG_THROTTLE(1.0, "Waiting for path and vehicle status messages...");
    return;
  }

  // 检查是否有加载的控制器
  if (controllers_.empty())
  {
    ROS_WARN_THROTTLE(1.0, "No controllers loaded, cannot compute control commands");
    return;
  }

  // 创建控制指令并设置默认值
  race_msgs::Control control_cmd;
  control_cmd.header.stamp = ros::Time::now();
  control_cmd.control_mode = race_msgs::Control::THROTTLE_BRAKE_ONLY;
  control_cmd.throttle = 0.0;
  control_cmd.brake = 0.0;
  control_cmd.gear = race_msgs::Control::GEAR_NEUTRAL;
  control_cmd.emergency = false;
  control_cmd.hand_brake = false;
  control_cmd.clutch = false;
  control_cmd.steering_mode = race_msgs::Control::FRONT_STEERING_MODE;

  // 依次调用每个控制器插件计算控制指令
  // 注意：后调用的插件可以覆盖前面插件的计算结果
  for (const auto& controller : controllers_)
  {
    controller->computeControl(*current_status_, *current_path_, control_cmd);
  }

  // 发布控制指令
  control_pub_.publish(control_cmd);
}

} // namespace race_tracker

int main(int argc, char**argv)
{
  ros::init(argc, argv, "controller_manager");
  ros::NodeHandle nh;
  ros::NodeHandle private_nh("~");

  try
  {
    race_tracker::ControllerManager manager(nh, private_nh);
    ros::spin();
  }
  catch (const std::exception& e)
  {
    ROS_FATAL_STREAM("Error in controller manager: " << e.what());
    return 1;
  }

  return 0;
}
