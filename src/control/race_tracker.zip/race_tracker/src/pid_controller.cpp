#include "race_tracker/pid_controller.h"
#include <tf/transform_datatypes.h>
#include <cmath>

namespace race_tracker
{

PIDController::PIDController()
  : kp_(0.5), ki_(0.1), kd_(0.05),
    max_output_(1.0), min_output_(-1.0),
    max_integral_(1.0), min_integral_(-1.0),
    integral_(0.0), prev_error_(0.0),
    max_speed_(20.0), min_speed_(0.0),
    throttle_deadzone_(0.05), brake_deadzone_(0.05),
    throttle_scale_(1.0), brake_scale_(1.0)
{
}

bool PIDController::initialize(ros::NodeHandle& nh, ros::NodeHandle& private_nh)
{
  // 从参数服务器加载PID参数
  private_nh.param("kp", kp_, kp_);
  private_nh.param("ki", ki_, ki_);
  private_nh.param("kd", kd_, kd_);
  
  // 加载输出限制参数
  private_nh.param("max_output", max_output_, max_output_);
  private_nh.param("min_output", min_output_, min_output_);
  
  // 加载积分限制参数
  private_nh.param("max_integral", max_integral_, max_integral_);
  private_nh.param("min_integral", min_integral_, min_integral_);
  
  // 加载速度限制参数
  private_nh.param("max_speed", max_speed_, max_speed_);
  private_nh.param("min_speed", min_speed_, min_speed_);
  
  // 加载油门刹车映射参数
  private_nh.param("throttle_deadzone", throttle_deadzone_, throttle_deadzone_);
  private_nh.param("brake_deadzone", brake_deadzone_, brake_deadzone_);
  private_nh.param("throttle_scale", throttle_scale_, throttle_scale_);
  private_nh.param("brake_scale", brake_scale_, brake_scale_);

  // 初始化时间
  last_time_ = ros::Time::now();
  
  ROS_INFO_STREAM("PIDController initialized with parameters: "
                  << "kp=" << kp_ << ", ki=" << ki_ << ", kd=" << kd_ << ", "
                  << "max_speed=" << max_speed_);

  return true;
}

void PIDController::computeControl(const race_msgs::VehicleStatus& vehicle_status,
                                  const race_msgs::Path& path,
                                  race_msgs::Control& control_cmd)
{
  if (path.points.empty())
  {
    ROS_WARN_THROTTLE(1.0, "PIDController: Received empty path");
    // 如果没有路径，施加刹车
    control_cmd.throttle = 0.0;
    control_cmd.brake = 0.1;  // 轻微刹车
    return;
  }

  // 查找当前车辆对应的路径点
  int nearest_idx = findNearestPoint(vehicle_status.pose, path);
  if (nearest_idx == -1)
  {
    ROS_WARN_THROTTLE(1.0, "PIDController: Could not find nearest path point");
    control_cmd.throttle = 0.0;
    control_cmd.brake = 0.1;
    return;
  }

  // 获取目标速度（来自路径点）
  double target_speed = path.points[nearest_idx].velocity;
  
  // 限制目标速度在允许范围内
  target_speed = std::max(min_speed_, std::min(max_speed_, target_speed));
  
  // 获取当前车辆速度（使用x方向的线速度）
  double current_speed = vehicle_status.vel.linear.x;
  
  // 计算时间间隔
  ros::Time current_time = ros::Time::now();
  double dt = (current_time - last_time_).toSec();
  last_time_ = current_time;
  
  if (dt <= 0.0)
  {
    ROS_WARN_THROTTLE(1.0, "PIDController: Invalid time interval");
    return;
  }

  // 计算PID控制输出
  double pid_output = computePID(target_speed, current_speed, dt);
  
  // 根据控制模式设置不同的控制指令
  if (control_cmd.control_mode == race_msgs::Control::THROTTLE_BRAKE_ONLY)
  {
    // 映射PID输出到油门和刹车
    if (pid_output > 0)
    {
      // 正输出对应油门
      control_cmd.throttle = std::max(throttle_deadzone_, pid_output * throttle_scale_);
      control_cmd.brake = 0.0;
    }
    else if (pid_output < 0)
    {
      // 负输出对应刹车
      control_cmd.throttle = 0.0;
      control_cmd.brake = std::max(brake_deadzone_, -pid_output * brake_scale_);
    }
    else
    {
      // 零输出时油门刹车都为零
      control_cmd.throttle = 0.0;
      control_cmd.brake = 0.0;
    }
  }
  else if (control_cmd.control_mode == race_msgs::Control::DES_SPEED_ONLY)
  {
    // 设置目标速度
    control_cmd.longitudinal.velocity = target_speed;
  }
  else if (control_cmd.control_mode == race_msgs::Control::DES_ACCEL_ONLY)
  {
    // 简单将PID输出作为目标加速度
    control_cmd.longitudinal.acceleration = pid_output;
  }

  // 设置前进档
  if (target_speed > 0.1 && control_cmd.gear != race_msgs::Control::GEAR_1)
  {
    control_cmd.gear = race_msgs::Control::GEAR_1;
  }
  else if (target_speed <= 0.1 && control_cmd.gear != race_msgs::Control::GEAR_NEUTRAL)
  {
    control_cmd.gear = race_msgs::Control::GEAR_NEUTRAL;
  }
}

int PIDController::findNearestPoint(const geometry_msgs::Pose& vehicle_pose, const race_msgs::Path& path)
{
  if (path.points.empty())
    return -1;

  // 车辆位置
  double x = vehicle_pose.position.x;
  double y = vehicle_pose.position.y;

  // 寻找最近的路径点
  double min_dist = std::numeric_limits<double>::max();
  int nearest_idx = 0;

  for (size_t i = 0; i < path.points.size(); ++i)
  {
    double px = path.points[i].pose.position.x;
    double py = path.points[i].pose.position.y;
    double dist = hypot(px - x, py - y);
    
    if (dist < min_dist)
    {
      min_dist = dist;
      nearest_idx = i;
    }
  }

  return nearest_idx;
}

double PIDController::computePID(double setpoint, double process_value, double dt)
{
  // 计算误差
  double error = setpoint - process_value;
  
  // 比例项
  double proportional = kp_ * error;
  
  // 积分项（带积分限制）
  integral_ += ki_ * error * dt;
  integral_ = std::max(min_integral_, std::min(max_integral_, integral_));
  
  // 微分项（带防微分冲击）
  double derivative = 0.0;
  if (dt > 0)
  {
    derivative = kd_ * (error - prev_error_) / dt;
  }
  
  // 保存当前误差用于下一次计算
  prev_error_ = error;
  
  // 计算总输出并限制范围
  double output = proportional + integral_ + derivative;
  return std::max(min_output_, std::min(max_output_, output));
}

} // namespace race_tracker

// 注册插件
#include <pluginlib/class_list_macros.h>
PLUGINLIB_EXPORT_CLASS(race_tracker::PIDController, race_tracker::ControllerPlugin)
