#ifndef RACE_TRACKER_CONTROLLER_MANAGER_H
#define RACE_TRACKER_CONTROLLER_MANAGER_H

#include <ros/ros.h>
#include <pluginlib/class_loader.h>
#include <race_msgs/Path.h>
#include <race_msgs/VehicleStatus.h>
#include <race_msgs/Control.h>
#include "controller_plugin.h"

namespace race_tracker
{

class ControllerManager
{
public:
  /**
   * @brief 构造函数
   */
  ControllerManager(ros::NodeHandle& nh, ros::NodeHandle& private_nh);

  /**
   * @brief 析构函数
   */
  ~ControllerManager() = default;

private:
  /**
   * @brief 路径消息回调函数
   * @param msg 路径消息
   */
  void pathCallback(const race_msgs::Path::ConstPtr& msg);

  /**
   * @brief 车辆状态消息回调函数
   * @param msg 车辆状态消息
   */
  void vehicleStatusCallback(const race_msgs::VehicleStatus::ConstPtr& msg);

  /**
   * @brief 执行控制计算
   */
  void computeControl();

  ros::NodeHandle nh_;                  ///< 节点句柄
  ros::NodeHandle private_nh_;          ///< 私有节点句柄
  
  ros::Subscriber path_sub_;            ///< 路径订阅者
  ros::Subscriber vehicle_status_sub_;  ///< 车辆状态订阅者
  ros::Publisher control_pub_;          ///< 控制指令发布者

  race_msgs::Path::ConstPtr current_path_;          ///< 当前路径
  race_msgs::VehicleStatus::ConstPtr current_status_; ///< 当前车辆状态

  boost::shared_ptr<pluginlib::ClassLoader<ControllerPlugin>> controller_loader_; ///< 插件加载器
  std::vector<boost::shared_ptr<ControllerPlugin>> controllers_; ///< 控制器插件列表

  std::string path_topic_;       ///< 路径话题名称
  std::string vehicle_status_topic_; ///< 车辆状态话题名称
  std::string control_topic_;    ///< 控制指令话题名称
  
  double control_rate_;          ///< 控制频率
  ros::Timer control_timer_;     ///< 控制定时器
};

} // namespace race_tracker

#endif // RACE_TRACKER_CONTROLLER_MANAGER_H
