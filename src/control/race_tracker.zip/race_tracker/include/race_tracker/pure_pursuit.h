#ifndef RACE_TRACKER_PURE_PURSUIT_H
#define RACE_TRACKER_PURE_PURSUIT_H

#include "controller_plugin.h"
#include <tf/transform_datatypes.h>

namespace race_tracker
{

class PurePursuit : public ControllerPlugin
{
public:
  /**
   * @brief 构造函数
   */
  PurePursuit();

  /**
   * @brief 析构函数
   */
  ~PurePursuit() override = default;

  /**
   * @brief 初始化插件
   * @param nh 节点句柄
   * @param private_nh 私有节点句柄
   * @return 初始化是否成功
   */
  bool initialize(ros::NodeHandle& nh, ros::NodeHandle& private_nh) override;

  /**
   * @brief 执行控制计算
   * @param vehicle_status 车辆状态
   * @param path 参考路径
   * @param control_cmd 控制指令（输入输出参数）
   */
  void computeControl(const race_msgs::VehicleStatus& vehicle_status,
                     const race_msgs::Path& path,
                     race_msgs::Control& control_cmd) override;

  /**
   * @brief 获取插件名称
   * @return 插件名称
   */
  std::string getPluginName() const override { return "pure_pursuit"; }

private:
  /**
   * @brief 查找目标路径点
   * @param vehicle_pose 车辆当前位姿
   * @param path 参考路径
   * @return 目标路径点索引，-1表示未找到
   */
  int findTargetPoint(const geometry_msgs::Pose& vehicle_pose, const race_msgs::Path& path);

  /**
   * @brief 计算转向角
   * @param vehicle_pose 车辆当前位姿
   * @param target_point 目标路径点
   * @return 计算得到的转向角
   */
  double calculateSteeringAngle(const geometry_msgs::Pose& vehicle_pose, 
                               const race_msgs::PathPoint& target_point);

  double wheel_base_;          ///< 轴距
  double lookahead_distance_;  ///< 前视距离
  double max_steering_angle_;  ///< 最大转向角
  double min_steering_angle_;  ///< 最小转向角
};

} // namespace race_tracker

#endif // RACE_TRACKER_PURE_PURSUIT_H
