#ifndef RACE_TRACKER_CONTROLLER_PLUGIN_H
#define RACE_TRACKER_CONTROLLER_PLUGIN_H

#include <ros/ros.h>
#include <race_msgs/Path.h>
#include <race_msgs/VehicleStatus.h>
#include <race_msgs/Control.h>

namespace race_tracker
{

class ControllerPlugin
{
public:
  /**
   * @brief 构造函数
   */
  ControllerPlugin() = default;

  /**
   * @brief 析构函数
   */
  virtual ~ControllerPlugin() = default;

  /**
   * @brief 初始化插件
   * @param nh 节点句柄
   * @param private_nh 私有节点句柄
   * @return 初始化是否成功
   */
  virtual bool initialize(ros::NodeHandle& nh, ros::NodeHandle& private_nh) = 0;

  /**
   * @brief 执行控制计算
   * @param vehicle_status 车辆状态
   * @param path 参考路径
   * @param control_cmd 控制指令（输入输出参数）
   */
  virtual void computeControl(const race_msgs::VehicleStatus& vehicle_status,
                             const race_msgs::Path& path,
                             race_msgs::Control& control_cmd) = 0;

  /**
   * @brief 获取插件名称
   * @return 插件名称
   */
  virtual std::string getPluginName() const = 0;
};

} // namespace race_tracker

#endif // RACE_TRACKER_CONTROLLER_PLUGIN_H
