#ifndef RACE_TRACKER_PID_CONTROLLER_H
#define RACE_TRACKER_PID_CONTROLLER_H

#include "controller_plugin.h"
#include <deque>

namespace race_tracker
{

class PIDController : public ControllerPlugin
{
public:
  /**
   * @brief 构造函数
   */
  PIDController();

  /**
   * @brief 析构函数
   */
  ~PIDController() override = default;

  /**
   * @brief 初始化插件
   * @param nh 节点句柄
   * @param private_nh 私有节点句柄
   * @return 初始化是否成功
   */
  bool initialize(ros::NodeHandle& nh, ros::NodeHandle& private_nh) override;

  /**
   * @brief 执行控制计算
   * @param vehicle_status 车辆状态
   * @param path 参考路径
   * @param control_cmd 控制指令（输入输出参数）
   */
  void computeControl(const race_msgs::VehicleStatus& vehicle_status,
                     const race_msgs::Path& path,
                     race_msgs::Control& control_cmd) override;

  /**
   * @brief 获取插件名称
   * @return 插件名称
   */
  std::string getPluginName() const override { return "pid_controller"; }

private:
  /**
   * @brief 查找当前车辆位置对应的路径点
   * @param vehicle_pose 车辆当前位姿
   * @param path 参考路径
   * @return 对应的路径点索引，-1表示未找到
   */
  int findNearestPoint(const geometry_msgs::Pose& vehicle_pose, const race_msgs::Path& path);

  /**
   * @brief 计算PID控制输出
   * @param setpoint 设定值
   * @param process_value 当前值
   * @param dt 时间间隔
   * @return PID控制输出
   */
  double computePID(double setpoint, double process_value, double dt);

  // PID参数
  double kp_;         ///< 比例系数
  double ki_;         ///< 积分系数
  double kd_;         ///< 微分系数
  
  // 输出限制
  double max_output_; ///< 最大输出
  double min_output_; ///< 最小输出
  
  // 积分限制
  double max_integral_; ///< 最大积分值
  double min_integral_; ///< 最小积分值
  
  // PID状态
  double integral_;   ///< 积分项
  double prev_error_; ///< 上一次误差
  ros::Time last_time_; ///< 上一次计算时间
  
  // 速度相关参数
  double max_speed_;  ///< 最大允许速度
  double min_speed_;  ///< 最小允许速度
  
  // 油门和刹车映射参数
  double throttle_deadzone_; ///< 油门死区
  double brake_deadzone_;    ///< 刹车死区
  double throttle_scale_;    ///< 油门缩放系数
  double brake_scale_;       ///< 刹车缩放系数
};

} // namespace race_tracker

#endif // RACE_TRACKER_PID_CONTROLLER_H
